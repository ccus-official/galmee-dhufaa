# Galmee Dhufaa: Firebase kaa'uu (Setup)

Faayilonni kun zip keessa jiru:
- `index.html`, `sw.js`, `manifest.webmanifest`, `icon-*.png`: app (website irratti kaa'aman)
- `firestore.rules`: seera nageenyaa (Firebase keessatti maxxansi)

## 1. Firebase keessatti (daqiiqaa ~5)
1. console.firebase.google.com → project `galmee-dhufaa`.
2. **Build → Authentication → Sign-in method → Email/Password** dandeessisee jiraachuu mirkaneessi.
3. **Build → Firestore Database** uumamee jiraachuu mirkaneessi.
4. **Firestore Database → Rules** tab banii, wanta jiru hunda haqii, `firestore.rules` keessaa hunda **kopii godhii maxxansi**, **Publish** tuqi. Dogoggora yoo agarsiise, barreeffama sana natti ergi.

## 2. App website irratti kaa'i (daqiiqaa ~3)
Karaa salphaa: **netlify.com/drop**. Zip unzip godhii folder guutuu (`index.html` jiru) harkisii itti gadi dhiisi. Link argatta (fkn. `https://xxxx.netlify.app`).
Seensa email/jecha icciitii irratti kun baay'ee hin barbaachisu. Garuu yoo Firebase irraa "unauthorized-domain" dogoggora argite: **Authentication → Settings → Authorized domains** keessatti domain kee (fkn. `xxxx.netlify.app`) dabali.

## 3. Bilbila Android irratti
1. Link Chrome irratti bani, **interneetii irra jiruu**.
2. **Seensa** tab → akaawuntii uumi (Hogganaa duraan). Mana barnootaa uumi, koodii argatte barsiisotaaf kenni.
3. Bakka tokko tokko (daqiiqaa 1) app'n akka banamu eegi, Chrome menu → **Add to Home screen**.
4. Qorannoo: Airplane mode kaasi, app bani, galmee galmeessi. Interneet deebisi. "Wal-simateera" jedhee mul'ata.
Mirkaneessuuf: bilbila tokko irratti hogganaa, bilbila biraa irratti barsiisaa seensi, galmee wal-ilaali.

## Gahee fi seera
- **Hogganaa:** kutaa hunda ni argaa, barsiisota kutaa kenna/baasa, galmee yeroo kamiyyuu sirreessa.
- **Barsiisaa:** kutaa isaaf kenname (ykn mataan isaa uume) qofa. Kutaa haquu hin danda'u.
- Barsiisaan galmee guyyaa **3 booda** sirreessuu hin danda'u. **Beeksisa:** seera kun amma app keessatti qofa eegama (Rules keessatti miti). Nama app irraa alatti database tuqu danda'u irratti hin eegu. Yoo barbaachise booda Rules keessatti cimsina.

## Gatii
Firebase Spark (bilisaa): guyyaatti dubbisuu 50,000 fi barreessuu 20,000. Mana barnootaa xiqqaa/giddu-galeessaaf ga'aadha. Yoo ittiin darbite, natti himi.

## Nageenya (gorsa)
- `firebaseConfig` dhoksaa miti, garuu Google Cloud Console → APIs & Services → Credentials keessatti API key kana **domain kee qofaaf** daangessuu ni dandeessa.
- "Service account" key gonkumaa nama kamiyyuu hin kenninaa.
